document.addEventListener('DOMContentLoaded', () => {
    // Carousel functionality
    const carouselTrack = document.getElementById('carouselTrack');
    const slides = document.querySelectorAll('.carousel-slide');
    const indicatorsContainer = document.querySelector('.carousel-indicators');
    let indicators = [];
    //const prevBtn = document.getElementById('carouselPrev');
    //const nextBtn = document.getElementById('carouselNext');

    let currentSlide = 0;
    const totalSlides = slides.length;

    // Build indicators dynamically based on slide count
    const buildIndicators = () => {
        if (!indicatorsContainer) return;
        indicatorsContainer.innerHTML = '';
        indicators = Array.from({ length: totalSlides }, (_, i) => {
            const btn = document.createElement('button');
            btn.className = 'indicator' + (i === currentSlide ? ' active' : '');
            btn.type = 'button';
            btn.setAttribute('aria-label', `Slide ${i + 1}`);
            btn.setAttribute('aria-controls', 'carouselTrack');
            btn.dataset.slide = String(i);
            indicatorsContainer.appendChild(btn);
            btn.addEventListener('click', () => {
                stopAutoPlay();
                goToSlide(i);
                startAutoPlay();
            });
            return btn;
        });
    };

    // Auto-play carousel with 5 second interval
    let autoPlayInterval;

    const startAutoPlay = () => {
        autoPlayInterval = setInterval(() => {
            goToSlide((currentSlide + 1) % totalSlides);
        }, 5000); 
    };

    const stopAutoPlay = () => {
        clearInterval(autoPlayInterval);
    };

    // Go to specific slide
    const goToSlide = (slideIndex) => {
        // Update current slide index
        currentSlide = slideIndex;

        // Update transform for smooth sliding
        const translateX = -currentSlide * 100;
        carouselTrack.style.transform = `translateX(${translateX}%)`;

        // Update indicators
        indicators.forEach((indicator, index) => {
            if (index === currentSlide) {
                indicator.classList.add('active');
                indicator.setAttribute('aria-selected', 'true');
            } else {
                indicator.classList.remove('active');
                indicator.setAttribute('aria-selected', 'false');
            }
        });
    };

    // Previous button
    /* // Previous button (optional, currently disabled)
    prevBtn.addEventListener('click', () => {
        stopAutoPlay();
        goToSlide((currentSlide - 1 + totalSlides) % totalSlides);
        startAutoPlay();
    });

    // Next button (optional, currently disabled)
    nextBtn.addEventListener('click', () => {
        stopAutoPlay();
        goToSlide((currentSlide + 1) % totalSlides);
        startAutoPlay();
    }); */

    // Build indicators at startup
    buildIndicators();

    // Pause on hover
    const carouselContainer = document.querySelector('.carousel-container');
    carouselContainer.addEventListener('mouseenter', stopAutoPlay);
    carouselContainer.addEventListener('mouseleave', startAutoPlay);

    // Start auto-play
    startAutoPlay();

    // Touch/swipe support for mobile
    let touchStartX = 0;
    let touchEndX = 0;

    carouselContainer.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoPlay();
    });

    carouselContainer.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
        startAutoPlay();
    });

    const handleSwipe = () => {
        if (touchEndX < touchStartX - 50) {
            // Swipe left
            goToSlide((currentSlide + 1) % totalSlides);
        }
        if (touchEndX > touchStartX + 50) {
            // Swipe right
            goToSlide((currentSlide - 1 + totalSlides) % totalSlides);
        }
    };

    // Existing sidebar toggle code
    const sidebar = document.getElementById('sidebar');
    const sidebarToggleInline = document.getElementById('sidebarToggleInline');

    // Toggle from inline button
    sidebarToggleInline.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
    });

    // Existing chatbot code
    const chatbotBtn = document.getElementById('ai-chatbot-btn');
    const heroChatbotBtn = document.getElementById('hero-chatbot-btn');
    const chatbotWindow = document.getElementById('chatbot-window');
    const closeChatbot = document.getElementById('close-chatbot');
    const chatbotInput = document.getElementById('chatbot-input');
    const chatbotSend = document.getElementById('chatbot-send');
    const chatbotMessages = document.getElementById('chatbot-messages');

    // Open chatbot
    const openChatbot = () => {
        chatbotWindow.classList.add('active');
    };

    // Close chatbot
    const closeChatbotWindow = () => {
        chatbotWindow.classList.remove('active');
    };

    chatbotBtn.addEventListener('click', openChatbot);
    if (heroChatbotBtn) {
        heroChatbotBtn.addEventListener('click', openChatbot);
    }
    closeChatbot.addEventListener('click', closeChatbotWindow);

    // Send message
    const sendMessage = () => {
        const message = chatbotInput.value.trim();
        if (message) {
            // Add user message
            const userMsg = document.createElement('div');
            userMsg.classList.add('user-message');
            userMsg.textContent = message;
            chatbotMessages.appendChild(userMsg);

            // Clear input
            chatbotInput.value = '';

            // Simulate bot response
            setTimeout(() => {
                const botMsg = document.createElement('div');
                botMsg.classList.add('bot-message');
                botMsg.textContent = 'Thank you for your message. Our AI assistant is currently being configured.';
                chatbotMessages.appendChild(botMsg);

                // Scroll to bottom
                chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
            }, 1000);

            // Scroll to bottom
            chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
        }
    };

    chatbotSend.addEventListener('click', sendMessage);
    chatbotInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Keyboard navigation for accessibility
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && chatbotWindow.classList.contains('active')) {
            closeChatbotWindow();
        }
    });
});
