document.addEventListener('DOMContentLoaded', () => {
    // Knowledge Base specific functionality
    const kbList = document.getElementById('kbList');
    const kbContent = document.getElementById('kbContent');
    const kbTitle = document.getElementById('kbTitle');
    const kbTitleBreadcrumb = document.getElementById('kbTitleBreadcrumb');
    const categoryBreadcrumb = document.getElementById('categoryBreadcrumb');
    const editBtn = document.getElementById('editBtn');
    const saveBtn = document.getElementById('saveBtn');
    const cancelEdit = document.getElementById('cancelEdit');
    const kbSearch = document.getElementById('kbSearch');
    const categoryFilter = document.getElementById('categoryFilter');
    const lastUpdated = document.getElementById('lastUpdated');
    const author = document.getElementById('author');
    const views = document.getElementById('views');

    let activeLi = null;
    let originalContent = '';

    function setActive(li) {
        if (!li) return;

        // Remove active class from all items
        document.querySelectorAll('.kb-item').forEach(item => {
            item.classList.remove('active');
        });

        // Add active class to selected item
        li.classList.add('active');
        activeLi = li;

                const title = li.querySelector('.kb-item-title').textContent;
        const category = li.dataset.category || 'General';
        const content = li.dataset.content || '';
        const meta = li.querySelector('.kb-item-meta').textContent;

        kbTitle.textContent = title;
        kbTitleBreadcrumb.textContent = title;
        categoryBreadcrumb.textContent = category;
        kbContent.innerHTML = content || '<p class="muted">No content available for this article.</p>';

        // Update metadata
        const timeMatch = meta.match(/Updated (.+)/);
        if (timeMatch) {
            lastUpdated.textContent = timeMatch[1];
        }

        // Reset edit state
        kbContent.removeAttribute('contenteditable');
        editBtn.style.display = 'inline-flex';
        saveBtn.style.display = 'none';
        cancelEdit.style.display = 'none';
        kbContent.style.border = '';
        kbContent.style.padding = '';
    }

    // Article selection
    kbList.addEventListener('click', (e) => {
        const li = e.target.closest('.kb-item');
        if (li) setActive(li);
    });

    // Edit functionality
    editBtn.addEventListener('click', () => {
        if (!activeLi) {
            alert('Please select an article to edit');
            return;
        }
        originalContent = kbContent.innerHTML;
        kbContent.setAttribute('contenteditable', 'true');
        kbContent.focus();
        editBtn.style.display = 'none';
        saveBtn.style.display = 'inline-flex';
        cancelEdit.style.display = 'inline-flex';
    });

    // Save functionality
    saveBtn.addEventListener('click', () => {
        if (!activeLi) return;

        const updatedContent = kbContent.innerHTML;
        activeLi.dataset.content = updatedContent;

        // Update the last updated time
        const now = new Date();
        const timeAgo = 'just now';
        lastUpdated.textContent = timeAgo;

        // Update the meta in the list item
        const metaElement = activeLi.querySelector('.meta-time');
        if (metaElement) {
            metaElement.textContent = 'Updated ' + timeAgo;
        }

        // Reset edit mode
        kbContent.removeAttribute('contenteditable');
        editBtn.style.display = 'inline-flex';
        saveBtn.style.display = 'none';
        cancelEdit.style.display = 'none';

        // Show success notification
        showNotification('Article saved successfully!', 'success');
    });

    // Cancel edit functionality
    cancelEdit.addEventListener('click', () => {
        if (!activeLi) return;

        kbContent.innerHTML = originalContent;
        kbContent.removeAttribute('contenteditable');
        editBtn.style.display = 'inline-flex';
        saveBtn.style.display = 'none';
        cancelEdit.style.display = 'none';
    });

    // Search functionality
    kbSearch.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        filterArticles(searchTerm, categoryFilter.value);
    });

    // Category filter functionality
    categoryFilter.addEventListener('change', (e) => {
        filterArticles(kbSearch.value.toLowerCase(), e.target.value);
    });

    // Filter articles function
    function filterArticles(searchTerm, category) {
        document.querySelectorAll('.kb-item').forEach(item => {
            const title = item.querySelector('.kb-item-title').textContent.toLowerCase();
            const itemCategory = item.dataset.category || '';
            const content = (item.dataset.content || '').toLowerCase();

            const matchesSearch = !searchTerm ||
                title.includes(searchTerm) ||
                content.includes(searchTerm);

            const matchesCategory = !category || itemCategory === category;

            if (matchesSearch && matchesCategory) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    }

    // Initialize with first visible article
    const firstItem = document.querySelector('.kb-item');
    if (firstItem) {
        setActive(firstItem);
    }

    // Sidebar toggle functionality
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggleInline');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
        });
    }

    // Global search functionality (cosmetic for now)
    const globalSearch = document.getElementById('globalSearch');
    if (globalSearch) {
        globalSearch.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                showNotification('Search functionality coming soon!', 'info');
            }
        });
    }

    // Print functionality
    const printBtn = document.querySelector('[title="Print"]');
    if (printBtn) {
        printBtn.addEventListener('click', () => {
            window.print();
        });
    }

    // Share functionality
    const shareBtn = document.querySelector('[title="Share"]');
    if (shareBtn) {
        shareBtn.addEventListener('click', () => {
            if (navigator.share && activeLi) {
                const title = activeLi.querySelector('.kb-item-title').textContent;
                navigator.share({
                    title: 'GSS Knowledge Base - ' + title,
                    text: 'Check out this article: ' + title,
                    url: window.location.href
                }).catch(err => console.log('Error sharing:', err));
            } else {
                // Fallback - copy link to clipboard
                copyToClipboard(window.location.href);
                showNotification('Link copied to clipboard!', 'success');
            }
        });
    }

    // Utility function to copy to clipboard
    function copyToClipboard(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
    }

    // Notification system
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            padding: 15px 20px;
            background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Add animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Ctrl/Cmd + E to edit
        if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
            e.preventDefault();
            if (editBtn.style.display !== 'none') {
                editBtn.click();
            }
        }

        // Ctrl/Cmd + S to save
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            if (saveBtn.style.display !== 'none') {
                saveBtn.click();
            }
        }

        // Escape to cancel edit
        if (e.key === 'Escape' && cancelEdit.style.display !== 'none') {
            cancelEdit.click();
        }

        // Ctrl/Cmd + F to focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
            e.preventDefault();
            kbSearch.focus();
        }
    });

    // Auto-save draft functionality
    let autoSaveTimer;
    kbContent.addEventListener('input', () => {
        if (kbContent.getAttribute('contenteditable') === 'true') {
            clearTimeout(autoSaveTimer);
            autoSaveTimer = setTimeout(() => {
                localStorage.setItem('kb_draft_' + activeLi.dataset.id, kbContent.innerHTML);
                showNotification('Draft saved', 'info');
            }, 2000);
        }
    });

    // Load draft if exists
    function loadDraft(articleId) {
        const draft = localStorage.getItem('kb_draft_' + articleId);
        if (draft && confirm('A draft exists for this article. Would you like to restore it?')) {
            kbContent.innerHTML = draft;
            editBtn.click();
        }
    }

    // Clear draft on save
    saveBtn.addEventListener('click', () => {
        if (activeLi) {
            localStorage.removeItem('kb_draft_' + activeLi.dataset.id);
        }
    });

    // Update article view count
    function updateViewCount() {
        const currentViews = parseInt(views.textContent) || 0;
        views.textContent = currentViews + 1;
    }

    // Call updateViewCount when article is selected
    kbList.addEventListener('click', (e) => {
        const li = e.target.closest('.kb-item');
        if (li && li !== activeLi) {
            setTimeout(updateViewCount, 500);
        }
    });

    // Chatbot integration
    const chatbotBtn = document.getElementById('ai-chatbot-btn');
    const chatbotWindow = document.getElementById('chatbot-window');
    const closeChatbot = document.getElementById('close-chatbot');
    const chatbotInput = document.getElementById('chatbot-input');
    const chatbotSend = document.getElementById('chatbot-send');
    const chatbotMessages = document.getElementById('chatbot-messages');

    if (chatbotBtn) {
        chatbotBtn.addEventListener('click', () => {
            chatbotWindow.classList.add('active');
            chatbotInput.focus();
        });
    }

        if (closeChatbot) {
        closeChatbot.addEventListener('click', () => {
            chatbotWindow.classList.remove('active');
        });
    }

    if (chatbotSend) {
        chatbotSend.addEventListener('click', () => {
            const message = chatbotInput.value.trim();
            if (message) {
                // Add user message
                const userMsg = document.createElement('div');
                userMsg.className = 'user-message';
                userMsg.textContent = message;
                chatbotMessages.appendChild(userMsg);

                // Clear input
                chatbotInput.value = '';

                // Simulate bot response
                setTimeout(() => {
                    const botMsg = document.createElement('div');
                    botMsg.className = 'bot-message';
                    botMsg.textContent = 'Thank you for your message. Our AI assistant is currently being configured.';
                    chatbotMessages.appendChild(botMsg);

                    // Scroll to bottom
                    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
                }, 1000);

                // Scroll to bottom
                chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
            }
        });
    }

    if (chatbotInput) {
        chatbotInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                chatbotSend.click();
            }
        });
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Escape key to close chatbot
        if (e.key === 'Escape' && chatbotWindow.classList.contains('active')) {
            chatbotWindow.classList.remove('active');
        }
    });
});

